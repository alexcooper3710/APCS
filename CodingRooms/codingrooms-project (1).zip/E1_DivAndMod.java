import java.util.*;

public class E1_DivAndMod {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);

        System.out.println("Enter an integer: ");
        int first = keyboard.nextInt(); 
        System.out.println("Enter a second integer: ");  
        int second = keyboard.nextInt();      
        //ONLY EDIT BELOW THIS LINE.

        int div1 = first / second;
        int mod1 = first % second;   //Edit all 0's to the correct equation, then delete this comment.
        int div2 = second / first;
        int mod2 = second % first;

        System.out.println(first + " / " + second + " = " + div1);
        System.out.println(first + " % " + second + " = " + mod1);
        System.out.println(second + " / " + first + " = " + div2);
        System.out.println(second + " % " + first + " = " + mod2);
        //Add three more print statements for each equation. Hint: copy & edit the one above this line!

    }
}