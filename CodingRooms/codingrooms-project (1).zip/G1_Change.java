import java.util.*;

public class G1_Change {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter the change in cents: ");
        int total = keyboard.nextInt();
        //ONLY EDIT BELOW THIS LINE:
        
        int quarters = total / 25;               //Hint: div (/) and mod (%) are very important in this exercise
        int remainder = total % 25;
        int dimes = remainder / 10;
        int remainder2 = remainder % 10;
        int nickels = remainder2 / 5;
        int remainder3 = remainder2 % 5;
        int pennies = remainder3;

        System.out.println("The minimum number of coins is: ");
        System.out.println("Quarters: " + quarters);
        System.out.println("Dimes: " + dimes);
        System.out.println("Nickels: " + nickels);
        System.out.println("Pennies: " + pennies);



        
    }
}