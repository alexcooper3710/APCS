import java.util.*;

public class F1_digits {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter in a three-digit number: ");
        int number = keyboard.nextInt();
        //ONLY EDIT BELOW THIS LINE:

        int hundred = number / 100;
        int temp = hundred*100;           //Sometimes a variable to temporarily store a number is helpful!
        int ten = (number - temp)/10; 
        int temp2 = ten * 10;
        int one = (number - temp - temp2);
        System.out.println("The hundreds-place digit is: " + hundred);
        System.out.println("The tens-place digit is: " + ten);
        System.out.println("The ones-place digit is: " + one);
       

    }
}