import java.text.NumberFormat;
public class Item {

    private String name;
    private double price;
    private int quantity;
    // -------------------------------------------------------
    // Create a new item with the given attributes.
    // -------------------------------------------------------

    public Item (String name, double price, int quantity){
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        
    }    
    
   
    // -------------------------------------------------------
    // Return a string with the information about the item
    // -------------------------------------------------------
    public String toString() {
        NumberFormat fmt = NumberFormat.getCurrencyInstance();
        return (
            name + "\t\t" + fmt.format(price) + "\t\t" + quantity + "\t\t" + fmt.format(price * quantity)
        );
    }
}