import java.util.Scanner;
public class Shop {
    public static void main(String[] args) {
        ShoppingCart cart = new ShoppingCart();
        Scanner scan = new Scanner(System. in);
        boolean repeat = true;
        while (repeat) {
            System.out.print("Enter an item name: ");
            String item = scan.next();
            System.out.print("Enter the item cost: ");
            double price = scan.nextDouble();
            System.out.print("Enter the item quantity: ");
            int quantity = scan.nextInt();
            cart.addToCart(item, price, quantity);
            //System.out.println(cart);
            System.out.println("You want to enter another item, true or false? ");
            repeat = scan.nextBoolean();
        }
        scan.close();
     System.out.println(cart);
    }
}