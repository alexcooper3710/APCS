public class Celebrity{
    private String name;
    private String hint;

    public Celebrity(String initname, String inithint){
        name = initname;
        hint = inithint;
    }
    public Celebrity(String initanswer){
        hint = "No Clue Provided";
        name = initanswer;
    }
    public String getClue(){
        return hint;
    }
    public String getAnswer(){
        return name;
    }
    public String setClue(String nhint){
        hint = nhint;
        return hint;
    }
    public String setAnswer(String nname){
        name = nname;
        return name;
    }
    public String toString()
   {
     return "Celebrity name: " + name +" Celebrity hint: " + hint;
   }

    
}