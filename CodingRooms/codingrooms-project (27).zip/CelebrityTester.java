public class CelebrityTester{
    public static void main (String[] args){
        Celebrity cel = new Celebrity("Big Bird", "Covered in yellow feathers");
        System.out.println(cel);
        Celebrity bob = new Celebrity("Bob");
        System.out.println(bob);
        System.out.println("Celebrity clue: " + cel.getClue());
        System.out.println("Celebrity name: " + cel.getAnswer());
        //changes the clue
        cel.setClue("Is 8 feet 2 inches tall");
        System.out.println("Celebrity clue: " + cel.getClue());

        //Change celebrity and clue
        cel.setAnswer("Vincent Cerf");
        cel.setClue("is known as the \"Father of the internet\"");
        System.out.println(cel);
    
    }
}