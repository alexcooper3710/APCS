public class Main {

    public static void main(String[] args) {
        int num =9;
        for(double i=0.0000001; i<=Math.sqrt(num);i+=0.0000001){
            if(i*i=num){
               System.out.println(i "^2 =" num);
            }
        }
    }

}
