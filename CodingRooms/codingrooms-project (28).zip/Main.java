public class Main {

    public static void main(String[] args) {
       int a = 10;

int b = 5 * 2;

System.out.print(a == b);
    }

}
