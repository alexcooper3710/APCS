
class Main {
  public static void main(String[] args) {
    // Activity 1: Call the sentimentVal method in Review with a word like "terrible" and print out the result
    /*double first = Review.sentimentVal("happily");
    double second = Review.sentimentVal("terrible");
    double third = Review.sentimentVal("cold");
    
    double num = Review.sentimentVal("warm");
    String word = Review.sentimentVal(0.5);
    double x = Review.sentimentVal ("good", "bad");
    System.out.println(num);
    System.out.println(word);
    System.out.println(x);
    */
     double total = Review.totalSentiment("myReview.txt");
    System.out.println(total);

    double stars = Review.starRating("myReview.txt");
    System.out.println(stars);
    
    String fake = Review.fakeReview("simpleReview.txt");
    System.out.println(fake);
 
  }
}