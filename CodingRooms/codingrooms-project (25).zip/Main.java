public class Main {

    public static void main(String[] args) {
        Resident r1 = new Resident(21,1,true);
        Resident r2 = new Resident(28,2,true);

        System.out.println(r1);
        System.out.println(r2);

    }

}
