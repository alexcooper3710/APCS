class Resident{
private int Age;
private int Gender;
private boolean Citizen;
 public Resident(int initAge,int initGender,boolean initCitizen){
    Age = initAge;
    Gender = initGender;
    Citizen = initCitizen;
 }

public String toString()
{
    if(Age>=21 && Gender==2 && Citizen== true){
        return "The resident is a " + Age +" Male who is eligible to vote, be drafted, and drink";
    }else if(Age>=21 && Gender==1 && Citizen== true){
        return "The resident is a " + Age + " Female who is eligible to vote, and drink";
    }else if(Age>=21 && Gender==2 && Citizen== false){
        return "The resident is a " + Age + " Male who can drink and drive";
    }else if(Age>=21 && Gender==1 && Citizen== false){
        return "The resident is a " + Age + " Female who can drink and drive";
    }else if(Age>=18 && Gender==2 && Citizen== true){
        return "The resident is a " + Age + " Male who can vote and drive";
    }else if(Age>=18 && Gender==1 && Citizen== true){
        return "The resident is a " + Age + " female who can vote and drive";
    }else if(Age>=18 && Gender==2 && Citizen== false){
        return "The resident is a " + Age + " Male who can drive";
    }else if(Age>=18 && Gender==1 && Citizen== false){
        return "The resident is a " + Age + " female who can drive";
    } else if(Age>=16 && Gender==2){
        return "The resident is a " + Age +" Male who can drive";
    }else if(Age>=16 && Gender==2){
        return "The resident is a " + Age +" female who can drive";
    }else if(Gender == 2){
        return "The resident is a "+ Age + " Male who is not eligible for anything";
    }else if(Gender == 1){
        return "The resident is a "+ Age + " Male who is not eligible for anything";
    } else {
        return "error";
    }
}
}