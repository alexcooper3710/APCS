// Alex Cooper - P1 - APCS

import java.util.*;

public class U1_P5_Easter{
    public static void main(String[] args){
        Scanner keyboard = new Scanner(System.in);
        int a,b,c,d,e,f,g,h,i,k,r,m,n,p;
        System.out.println("Enter the year including or after 1584: ");
        int y = keyboard.nextInt();
        a = y%19;
        b = y/100;
        c = y%100;
        d = b/4;
        e = b%4;
        f = (b+8)/25;
        g = (b-f+1)/3;
        h = (19*a+b-d-g+15)%30;
        i = c/4;
        k = c%4;
        r = (32+2*e+2*i-h-k)%7;
        m = (a+11*h+22*r)/451;
        n = (h+r-7*m+114)/31;
        p = (h+r-7*m+114)%31;
        

        if (n == 3 && y>= 1583){
            System.out.println("Easter falls on March" + " " + (p+1));
        }
        if (n == 4 && y>= 1583){
            System.out.println("Easter falls on April" +" "+ (p+1));
        }
    }
}