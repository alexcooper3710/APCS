public class StringTest {

    String test = "Abandoned";
    System.out.println(test);

    //String subString = test.substring(4);
    //System.out.println(subString);

    //int intexTest = test.indexOf(Ab);
    //System.out.println = (intexTest);

     //String s1 = new String("TUTORIALSPOINT");
     //String s2 = new String("TUTORIALSPOINT");
     //System.out.println(s1.equals(s2));



}
