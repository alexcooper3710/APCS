import java.util.*;
class Main {
public static void main(String[] args) {
ArrayList <Integer> mothree = new ArrayList<Integer>();
for (int i = 0; i < 100; i++){
mothree.add(3*i);
}
System.out.println(mothree);

}
}