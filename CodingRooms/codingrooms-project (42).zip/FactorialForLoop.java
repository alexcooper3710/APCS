public class FactorialForLoop {
    public static void main(String[] args) {
        System.out.println(Factorial(7));
    }
    public static int Factorial(int n) {

        if (n == 0) {
            return 1;
        } else {
            System.out.println(n);
            return n * (Factorial(n - 1));
        }
    }
}