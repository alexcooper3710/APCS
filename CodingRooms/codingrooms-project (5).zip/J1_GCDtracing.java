import java.util.*;

public class J1_GCDtracing {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);

        //EDIT BELOW THIS LINE
        System.out.println("Enter a non-negative integer: ");
        int num1 = keyboard.nextInt();       
        System.out.println("Enter a second non-negative integer: ");
        int num2 = keyboard.nextInt();      
        int temp = 0;       //Leave this as a "0" now

        //EDIT ABOVE THIS LINE
        while (num2 > 0){           //DONT TOUCH THIS LOOP
            temp = num1 % num2;     //This loops keeps happening until num2 is NOT > 0
            num1 = num2;            //We will learn more about loops in a later unit.
            num2 = temp;            //DONT TOUCH THIS LOOP
        }
        //EDIT BELOW THIS LINE

        System.out.println("The GCD is " + num1); //1 logic error here. Hint: code trace
    }
}