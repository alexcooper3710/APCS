import java.util.*;  

public class L1_SleepTime {    
    public static void main(String[] args) {    
        Scanner console = new Scanner(System.in);  
        System.out.println("Enter your birthdate"); 
        System.out.println("Year:");
        int byear = console.nextInt();
        System.out.println("Month:"); 
        int bmonth = console.nextInt();
        System.out.println("Day:"); 
        int bday = console.nextInt();
        //
        System.out.println("Enter today's date");
        System.out.println("Year:");
        int cyear = console.nextInt();
        System.out.println("Month:"); 
        int cmonth = console.nextInt();
        System.out.println("Day:"); 
        int cday = console.nextInt();
        int years = cyear- byear;
        int months = (years*12)+(cmonth-bmonth);
        int days = (months*30)+(cday-bday);
        int sleep = (days*8);
        System.out.println("You have been alive for " + days + " days.");
        System.out.println("You have slept for" + sleep +"hours total");
    }
}