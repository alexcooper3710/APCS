import java.util.*;

public class K1_TimeConversions {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("enter a time in minutes:");
        int total = keyboard.nextInt();
        int hours = total/60;
        int minutes = total%60;
        System.out.println("the total time is " + hours + ":" + minutes);
    }
}