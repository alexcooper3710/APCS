public class Main {

    public static void main(String[] args) {
      double a = 2.0;
      while(a>=1){
          a*=1.1;
          System.out.println(a);
      }
    }

}
