import java.util.*;
public class Main {

    public static void main(String[] args) {
        int [][] ticketInfo = {{25,20,25},{25,20,25}};
        String [][] seatingIngo = {{"Jamal","Maria"},{"Jake","Suzy"},{"Emma","Luke"}}
        System.out.println(Arrays.deepToString(numbers));
    }

}
