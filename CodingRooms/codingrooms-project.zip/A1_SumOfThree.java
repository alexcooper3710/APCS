/*
Lab 1 - SumOfThree.java
Modify this program that takes three integer numbers and prints their sum.
Every number is given on a separate line.
*/

import java.util.*;

public class A1_SumOfThree {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        // This is an example of a comment!
        // These comments will help explain what each line means.
        
        System.out.println("Enter the three integers: "); //This prints a message to the console!
        int first = keyboard.nextInt();  //This scans in an integer, assigns it to the variable 'first'
        int second = keyboard.nextInt();
        int third = keyboard.nextInt();

        // ONLY EDIT BELOW THIS LINE!
        
        int sum = first + second + third ;                     //What variables should we add together instead of "0"?

        // ONLY EDIT ABOVE THIS LINE!
        
        System.out.println("The sum is: " + sum);
    }
}
