import java.util.*;

public class D1_PlanetWeight {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);

        System.out.println("Enter how much a person weighs on earth in pounds(lbs): ");
        double earthWeight = keyboard.nextDouble();        

        //ONLY EDIT BELOW THIS LINE.

        double moonWeight = .17*earthWeight;
        double plutoWeight = 0.06666*earthWeight;
        double jupiterWeight = 2.53*earthWeight;
        double sunWeight = 28*earthWeight;
        System.out.println("Weight in pounds on each celestial body: "); //Don't edit this line
        System.out.println("Moon - " + moonWeight + " lbs");    //Don't edit this line
        System.out.println("Pluto - " + plutoWeight + " lbs");   //1 logic error in this line
        System.out.println("Jupiter - " + jupiterWeight + " lbs"); 
        System.out.println("Sun - " + sunWeight + " lbs"); 

    }
}