import java.util.*;

public class C1_PizzaCost {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);

        System.out.println("Enter the diameter of the pizza in inches: ");
        double diameter = keyboard.nextDouble();        

        //ONLY EDIT BELOW THIS LINE.

        double labor = 0.75;     //Remember Double-type "variables" store decimals!
        double rent = 1;            
        double materials = 0.05*diameter*diameter;

        System.out.println("The cost of making the pizza is: $" + (labor + rent + materials)); //1 logic error to fix here
    }
}