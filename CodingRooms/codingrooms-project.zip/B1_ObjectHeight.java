import java.util.*;

public class B1_ObjectHeight {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);

        System.out.println("Enter a time less than 4.5 seconds: ");
        double time = keyboard.nextDouble(); 

        //Only edit below this line.

        double height = 100-4.9*time*2;                     //Replace zero with a formula from the question.

        System.out.println("The height of the object is: " + height + " meters.");  //1 logic error to fix

    }
}