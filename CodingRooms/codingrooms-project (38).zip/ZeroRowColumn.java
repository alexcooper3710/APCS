import java.util.*;
public class ZeroRowColumn {
    int[][] matrix = {{ 0,  1,  4,  0},
                  { 3,  2,  6,  4},
                  {-1,  3,  1,  8},
                  {15,  7,  2,  0},
                  { 9,  4,  5,  6}};
    System.out.println matrix;
    int[][] zerorow = ZeroRowCol(matrix);
    System.out.println zerorow;
}
public static void zeroRowCol(int[][] matrix) {
	   int numRows = matrix.length;
    if (numRows == 0) {
        return; // nothing to do
    }
    int numCols = matrix[0].length;
    boolean[] zeroRows = new boolean[numRows];
    boolean[] zeroCols = new boolean[numCols];
    // First pass: detect which rows and columns contain a zero
    for (int i = 0; i < numRows; i++) {
        for (int j = 0; j < numCols; j++) {
            if (matrix[i][j] == 0) {
                zeroRows[i] = true;
                zeroCols[j] = true;
            }
        }
    }
    // Second pass: set elements to zero based on zeroRows and zeroCols flags
    for (int i = 0; i < numRows; i++) {
        for (int j = 0; j < numCols; j++) {
            if (zeroRows[i] || zeroCols[j]) {
                matrix[i][j] = 0;
            }
        }
    }
}
