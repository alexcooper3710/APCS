import java.util.*;
public class Spiral {
public static void main(String[] args) {
int[][] list = {{1,2,3,4,5},{6,7,8,9,10},{10,9,8,7,6},{5,4,3,2,1}};
System.out.println(Arrays.deepToString(list));
Integer[] swirl = spiral(list);
System.out.println(Arrays.deepToString(swirl));
}
public static int[] spiral(int[][] matrix) {
    int numRows = matrix.length;
    int numCols = matrix[0].length;
    int k = 0;
    int topRow = 0, bottomRow = numRows - 1, leftCol = 0, rightCol = numCols - 1;
    int[] result = new int[numRows * numCols];
    while (topRow <= bottomRow && leftCol <= rightCol) {
        for (int j = leftCol; j <= rightCol; j++) {
            result[k++] = matrix[topRow][j];
        }
        topRow++;
        for (int i = topRow; i <= bottomRow; i++) {
            result[k++] = matrix[i][rightCol];
        }
        rightCol--;
        if (topRow <= bottomRow) {
            for (int j = rightCol; j >= leftCol; j--) {
                result[k++] = matrix[bottomRow][j];
            }
            bottomRow--;
        }
        if (leftCol <= rightCol) {
            for (int i = bottomRow; i >= topRow; i--) {
                result[k++] = matrix[i][leftCol];
            }
            leftCol++;
        }
    }
    return result;
}
}