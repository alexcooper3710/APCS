import java.util.*;
public class Main {

    public static void main(String[] args) {
        String [] names = {"Joe","Bob","Bob","Susan","Jojo","Bob","Bobby","Andy"};

        ArrayList <String> students = new ArrayList <String>();

        for( int i = 0; i< names.length; i++){
            students.add(names[i]);
        }
        System.out.println(students);
        for(int i=0; i<students.size(); i++){
            if(students.get(i).substring(0,1).equals("J")){
                students.set(i, "Sue");
            }
        }
        System.out.println(students);
    for(int i=0; i<students.size(); i++){
            if(students.get(i).equals("Bob")){
                students.remove(i);
               i--;
            }
        }
        System.out.println(students);
    
    }

}
