class Employee
{
    private String name;
    private int year;
    private String Address;
   // keep track of the name, age, weight, type of animal, and breed of the pet

     public Employee(String initName,int initYear,String initAddress){
      name = initName;
      year = initYear;
      Address = initAddress;
   }

   // toString() method
   public String toString()
   {
     return name + "\t" + year + "\t\t" + Address + "- WallStreet";
   }
}
   // Write 2 constructors, accessor (get) methods, and a toString method. Use good commenting.

   // Don't forget to complete the main method in the TesterClass below!


public class TesterClass
{
   // main method for testing
   public static void main(String[] args)
   {
        Employee E1 = new Employee("Robert",1994,"64C");
        Employee E2 = new Employee("Sam",2000,"68D");
        Employee E3 = new Employee("John",1999, "26B");

       System.out.println("Name\tYear joined\tAddress");
       System.out.println(E1);
       System.out.println(E2);
       System.out.println(E3);
   }
 }
 
