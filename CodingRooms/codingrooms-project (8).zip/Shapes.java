//Replace MRetta with your first initial and last name comment below:
//AP_CS_ACooper_Shapes_2022

import java.util.*;
//import static java.lang.System.*;

public class Shapes {
    public static void main(String[] args){
        Scanner keyboard = new Scanner(System.in);

        //Rectangle
        System.out.println("Please enter the length of the room: ");
        double length1 = keyboard.nextDouble();
        System.out.println("Please enter the width of the room: ");
        double width1 = keyboard.nextDouble();

        Rectangle roomSize = new Rectangle(length1,width1);

        System.out.println(roomSize.toString());
        System.out.println(roomSize); //Automatically references toString. Overrides base parent class Object
        
        //Circle
        System.out.println("Please enter the radius of your circle");
        double rad = keyboard.nextDouble();
        Circle frisbee = new Circle(rad);
        System.out.println(frisbee.toString());
      


        //Sphere
        System.out.println("Please enter the radius of your sphere");
        double rad = keyboard.nextDouble();
        Sphere orb = new Sphere(rad);
        System.out.println(orb);

        //Cylinder
        System.out.println ("Please enter the radius of your cylinder");
        double rad = keyboard.nextDouble();
        System.out.println ("Please enter the height of your cylinder");
        double ht = keyboard.nextDouble();
        Cylinder soda = new Cylinder(rad, ht);//be sure this is the order for your constructor!!!
        System.out.println(soda);
        
        //Cone
        System.out.println ("Please enter the radius of your cone");
        double rad = keyboard.nextDouble();
        System.out.println ("Please enter the height of your cone");
        double ht = keyboard.nextDouble();
        Cone soda = new Cone(rad, ht);//be sure this is the order for your constructor!!!
        System.out.println(soda);

        //Box
        System.out.println("Please enter the length of the room: ");
        double length1 = keyboard.nextDouble();
        System.out.println("Please enter the width of the room: ");
        double width1 = keyboard.nextDouble();
        System.out.println("Please enter the height of the room: ");
        double height1 = keyboard.nextDouble();
        Box boxSize = new Box(length1,width1,height1);
        System.out.println(boxSize.toString());


    }
}