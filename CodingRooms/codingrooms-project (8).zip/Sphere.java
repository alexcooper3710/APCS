//This is the class file for creating Rectangle objects
//AP_CS_ACooper_Shapes_2022

public class Sphere{
    public double myRadius;
    
    //Constructor
    public Sphere(double radius){ 
       myRadius = radius;
       
    }
    
    //This method finds the volume of my Sphere
    public double getVolume(){   
        return (4/3)* Math.PI* Math.pow(myRadius,3);
    }

    //This method finds the surface area of my Sphere
    public double getSurfaceArea(){   
       return 4* Math.PI * Math.pow(myRadius,2);
    }

    //This method finds the diameter of the Sphere
    public double getDiameter(){   
        return 2*myRadius;
    }
    //This method converts information of the object to String format
    public String toString(){
        return "The Volume of my Sphere is: " + this.getVolume() + "\nThe surface area of my sphere is: " + this.getSurfaceArea() + "\nThe diameter of my sphere is: " + this.getDiameter();
    }
}