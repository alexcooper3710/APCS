//This is the class file for creating Rectangle objects
//AP_CS_ACooper_Shapes_2022

public class Rectangle{
    
    public double myLength, myWidth;
   
    //Constructor for objects of class Rectangle
    public Rectangle(double length, double width){ 
       myLength = length;
       myWidth = width; 
    }
    
    //This method finds the area of my rectangle
    public double getArea(){   
        return myLength*myWidth;
    }
    
    //This is a getter
    public double getLength(){   
        return myLength;
    }
    
    //This is a setter - allows a change of length
    public void setLength(double newLength){     
        myLength = newLength;
    }
 
    //This method finds the perimeter of my rectangle
    public double getPerim(){   
        return 2*(myLength + myWidth);
    }
    
    //This method finds the length of the diagonal of my rectangle
    public double getDiag(){   
        double cSquared = myLength*myLength + myWidth*myWidth;
        return Math.sqrt(cSquared);
    }
    
    //This method converts information of the object to String format
    public String toString(){
        return "The area of my Rectangle is: " + this.getArea() + "\nThe perimeter of my Rectangle is: " + this.getPerim() + "\nThe length of the diagonal of my Rectangle is: " + this.getDiag();
    }    
}
