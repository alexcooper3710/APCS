//This is the class file for creating Rectangle objects
//AP_CS_ACooper_Shapes_2022

public class Box{
    
    public double myLength, myWidth,myHeight;
   
    //Constructor for objects of class Rectangle
    public Box(double length, double width, double height){ 
       myLength = length;
       myWidth = width;
       myHeight = height; 
    }
    
    //This method finds the area of my Box
    public double getArea(){   
        return myLength*myWidth*myHeight;
    }

    //This method finds the perimeter of my Box
    public double getSArea(){   
        return 2*(myLength*myHeight+myLength*myWidth+myWidth*myLength);
    }
    
    //This method finds the length of the diagonal of my rectangle
    public double getDiag(){   
       return Math.sqrt(Math.pow(myLength,2)+Math.pow(myWidth,2)+Math.pow(myHeight,2));
    }
    
    //This method converts information of the object to String format
    public String toString(){
        return "The area of my Box is: " + this.getArea() + "\nThe surface area of my Rectangle is: " + this.getSArea() + "\nThe length of the diagonal of my Box is: " + this.getDiag();
    }    
}
