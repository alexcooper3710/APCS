//This is the class file for creating Cylinder objects
//AP_CS_ACooper_Shapes_2022

public class Cylinder{
    public double myRadius,myHeight;
    
    //Constructor
    public Cylinder(double radius, double height){ 
       myRadius = radius;
       myHeight = height;
    }
    
    //This method finds the volume of my cylinder
    public double getVolume(){   
        return Math.PI*Math.pow(myRadius,2)*myHeight;
    }

    //This method finds the surface area of my Sphere
    public double getSurfaceArea(){   
       return 2* Math.PI *myRadius*myHeight + 2*Math.PI*Math.pow(myRadius,2);
    }

    //This method finds the lateral area of the Sphere
    public double getlArea(){   
        return 2*Math.PI*myRadius*myHeight;
    }
    //This method converts information of the object to String format
    public String toString(){
        return "The Volume of my Cylinder is: " + this.getVolume() + "\nThe surface area of my Cylinder is: " + this.getSurfaceArea() + "\nThe lateral area of my Cylinder is: " + this.getlArea();
    }
}