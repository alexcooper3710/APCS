//This is the class file for creating Circle objects
//AP_CS_ACooper_Shapes_2022

public class Circle{
    public double myRadius;
    
    //Constructor
    public Circle(double radius){ 
       myRadius = radius;
    }
    
    //This method finds the area of my Circle
    public double getArea(){   
        return myRadius*myRadius*Math.PI;
    }

    //This method finds the circumference of my Circle
    public double getCircumference(){   
        return 2*Math.PI*myRadius;
    }

    //This method finds the diameter of the circle
    public double getDiameter(){   
        return 2*myRadius;
    }
    //This method converts information of the object to String format
    public String toString(){
        return "The area of my circle is: " + this.getArea() + "\nThe circumference of my circle is: " + this.getCircumference() + "\nThe diameter of my circle is: " + this.getDiameter();
    }
    
}