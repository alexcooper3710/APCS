import java.util.*;
public class Main {

    public static void main(String[] args) {
       
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter a number between 2 and 12: ");
        int sum = keyboard.nextInt();
            
        int die1 = (int)(Math.random()*6 )+ 1;
        int die2 = (int)(Math.random()*6 )+ 1;
        System.out.println(die1 + die2);

        while((die1+die2)!= sum){
            die1 = (int)(Math.random()*6 )+ 1;
            die2 = (int)(Math.random()*6 )+ 1;
            System.out.println(die1 + die2);
        }
    }

}
