val = 1
while val > 0:
    print(val)
    val+=1
    if val > 1000:
            val=0