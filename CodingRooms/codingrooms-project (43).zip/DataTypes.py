# DataType Output: str
x = "Hello World"
 
# DataType Output: int
x = 50
 
# DataType Output: float
x = 60.5
 
# DataType Output: complex
x = 3j
 
# DataType Output: list
x = ["geeks", "for", "geeks"]
 
# DataType Output: tuple
x = ("geeks", "for", "geeks")
 
# DataType Output: range
x = range(10)
 
# DataType Output: dict
x = {"name": "Suraj", "age": 24}
 
# DataType Output: set
x = {"geeks", "for", "geeks"}
 
# DataType Output: frozenset
x = frozenset({"geeks", "for", "geeks"})
 
# DataType Output: bool
x = True
 
# DataType Output: bytes
x = b"Geeks"
 
# DataType Output: bytearray
x = bytearray(4)
 
# DataType Output: memoryview
x = memoryview(bytes(6))
 
# DataType Output: NoneType
x = None