
/**
 * Write a description of class Life here.
 * 
 * @author Matt Retta
 * @version GameOfLife V1 2023
 * Char is similar to String, however it is a primitive type and stores only one character
 * Storing a Char using single quotes, String uses double quotes
 */

import java.util.*;
import java.io.*;
public class Life
{
    private char[][] city;

    public Life()
    {
        city = new char[22][22];
        for(int r = 0; r<22; r++)
        {
            for(int c = 0; c<22; c++)
            {
                city[r][c] = ' ';
            }
        }
        this.fillCity();
    }

    public void fillCity()
    {
        Scanner inFile;
    
    try{
        inFile = new Scanner(new File("life100.txt"));
        int loop, howmany, r, c;
    
        howmany = inFile.nextInt();
        for (loop = 1; loop <= howmany; loop++){
          r = inFile.nextInt();
          c = inFile.nextInt();
          city[r][c] = '*';
        }
    }catch(IOException e){
        System.out.println("Could not create Life! Error: " + e.getMessage());
    }
        
    }
    //isValid makes sure r,c is on the grid!
    public boolean isValid(int r, int c)
    { 
        return true;
        
    }
    public int isAlive(int r, int c){
        int count = 0;
        if(city[r][c]=='*')
        count++;
        return count;
    }

    public int countNeighbors(int r, int c)
    {
       int count = 0;
      if(city[r-1][c]=='*'){
            count++;
      }
        if(city[r-1][c-1]=='*'){
          count++;
      }
      if(city[r][c-1]=='*'){
          count++;
      }
      if(city[r+1][c]=='*'){
          count++;
      }
        if(city[r+1][c+1]=='*'){
          count++;
      }
      if(city[r][c+1]=='*'){
          count++;
      }
       if(city[r-1][c+1]=='*'){
          count++;
      }
       if(city[r+1][c-1]=='*'){
          count++;
      }
       
       return count;
        
    }

    public void nextGen(){
        char[][] newCity = new char[22][22];
    for (int r = 1; r < 21; r++) {
        for (int c = 1; c < 21; c++) {
            int count = countNeighbors(r, c);
            if (city[r][c] == '*' && (count == 2 || count == 3)) {
                newCity[r][c] = '*';
            } else if (city[r][c] == ' ' && count == 3) {
                newCity[r][c] = '*';
            } else {
                newCity[r][c] = ' ';
            }
        }
    }
    city = newCity;
}

  public void printLife (){
    int row, col;

    System.out.println("      12345678901234567890");
    System.out.println();   

    for (row = 1; row <= 20; row++)
    {
      System.out.print(row + "     ");

      for (col = 1; col <= 20; col++)
      {
          System.out.print(city[row][col]);
      }
      System.out.println();
    }
  }
  
  public int countLiving (){
    int count = 0;
    for(int r=0; r<city.length; r++){
        for(int c=0;c<city[0].length; c++){
            if(city[r][c]=='*')
            count++;
        }
    }
    return count;
  }
  public static void main(String[] args)
  {
      Scanner in = new Scanner(System.in);
      Life isGood = new Life();
      System.out.println("How many generations would you like to generate?");
      int gens = in.nextInt();
      int gen = 0;
      while(gens >= 0)
      {
          isGood.printLife();
          System.out.println("There are " + isGood.countLiving() + " members in generation " + gen + ".");
          isGood.nextGen();
          gens--;
          gen++;
      }

  }
}
