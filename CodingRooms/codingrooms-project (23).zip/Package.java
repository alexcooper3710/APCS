public class Package{
    private double length, width, height, weight;

    public Package(double dim1, double dim2, double dim3, double w){
        weight = w;
        if(dim1> dim2 && dim1>dim3){
            length = dim1;
            width = dim2;
            height = dim3;
        }

        else if(dim2> dim1 && dim2>dim3){
            length = dim2;
            width = dim1;
            height = dim3;
        }

        else if(dim3> dim2 && dim3>dim1){
            length = dim3;
            width = dim2;
            height = dim1;
        }
       
    }
    public String toString(){
    
        if((((2*height)+(2*width))>100)&& weight>70){
            return "package is too large & too heavy to ship";
        } else if(((2*height)+(2*width))>100){
            return "package is to large to ship";
        } else if(weight>70){
            return "package is too heavy to ship";
        } else{
            return "package can be shipped";
        }


    }
    /*
    public Package (double w){

    }
    public double getSize(){
         
    }
    */
}