import java.util.*;
public class Main {

    public static void main(String[] args) {
        ArrayList<String> syllables = new ArrayList<String>();

syllables.add("LA");

syllables.add(0, "DI");

syllables.set(1, "TU");

syllables.add("DA");

syllables.add(2, syllables.get(0));

syllables.remove(1);

System.out.println(syllables.toString());
    }

}
