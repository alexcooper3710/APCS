public class eightball {

    public static void main(String[]args){
        
        int roll99 = (int)(Math.random()*100);
        int roll5 = (int)(Math.random()*5);

        System.out.println(getAnswer( roll99, roll5 ));

    }

    public static String getAnswer(int category, int answer){

        String response = "";
        if (category >= 74){
            if (answer ==5){
                System.out.println("As I see it, Yes.");
            } else if(answer == 4){
                System.out.println("Signs point to yes");
            } else if(answer == 3){
                System.out.println("Outlook is good");
            } else if(answer == 2){
                System.out.println("Without a doubt");
            } else if(answer == 1){
                System.out.println("You may rely on it");
            }
            }

        if (category >=24 && category <74){
            if (answer ==5){
                System.out.println("Reply hazy, try again");
            } else if(answer == 4){
                System.out.println("ask again later");
            } else if(answer == 3){
                System.out.println("better not tell you now");
            } else if(answer == 2){
                System.out.println("I am forbidden to tell you");
            } else if(answer == 1){
                System.out.println("Concentrate and ask again");
            }
            }

        if (category <24){
            if (answer ==5){
                System.out.println("outlook not so good");
            } else if(answer == 4){
                System.out.println("nope");
            } else if(answer == 3){
                System.out.println("in your dreams");
            } else if(answer == 2){
                System.out.println("when pigs can fly");
            } else if(answer == 1){
                System.out.println("absolutely not");
            }
            }
        return response;
    }


}