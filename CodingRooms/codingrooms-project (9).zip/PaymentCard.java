//AP_CS_Unit 2_P2_ACooper_2022
public class PaymentCard{
    private double balance; 

    public PaymentCard(double openingBalance){
        balance = openingBalance;
    }

    public String toString(){
        return "this card has a balance of $" + balance;
    }

    public void eatFrugal(){
        balance=balance-1.30;

        if (balance<0){
            balance += 1.30;
        }

      
    }

    public void eatTooMuch(){
        balance=balance-21.75;
        
        if (balance<0){
            balance += 21.75;
        }
    }
    public void addMoney(double amount) {
        balance += amount;

        if (balance>150){
            balance=150;
        }
         if (0>balance){
            balance=0;
        }
       
    }

  
}