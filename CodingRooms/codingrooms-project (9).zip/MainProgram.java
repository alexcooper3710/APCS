//AP_CS_Unit 2_P2_ACooper_2022

public class MainProgram {

    public static void main(String[] args) {
    
        //PaymentCard card = new PaymentCard(100);
        //System.out.println(card);
        //card.eatFrugal();
        //System.out.println(card);
        //card.eatTooMuch();
        //card.eatFrugal();
        //System.out.println(card);

        //PaymentCard card = new PaymentCard(40);
        //System.out.println(card);
        //card.eatTooMuch();
        //System.out.println(card);
        //card.eatTooMuch();
        //System.out.println(card);

        //PaymentCard card = new PaymentCard(10);
        //System.out.println(card);
        //card.addMoney(15);
        //System.out.println(card);
        //card.addMoney(10);
        //System.out.println(card);
        //card.addMoney(200);
        //System.out.println(card);

        //PaymentCard card = new PaymentCard(10);
        //System.out.println("Paul: " + card);
        //card.addMoney(-15);
        //System.out.println("Paul: " + card);

        
        //PaymentCard paulsCard = new PaymentCard(80);
        //PaymentCard jordansCard = new PaymentCard(50);
        //paulsCard.eatTooMuch();
        //jordansCard.eatFrugal();
        //System.out.println("Pauls card:" + paulsCard);
        //System.out.println("Jordans card:" + jordansCard);
        //paulsCard.addMoney(20);
        //jordansCard.eatTooMuch();
        //System.out.println("Pauls card:" + paulsCard);
        //System.out.println("Jordans card:" + jordansCard);
        //paulsCard.eatFrugal();
        //paulsCard.eatFrugal();
        //jordansCard.addMoney(-15);
        //System.out.println("Pauls card:" + paulsCard);
        //System.out.println("Jordans card:" + jordansCard);
        //jordansCard.addMoney(200);
        //paulsCard.eatTooMuch();
        //paulsCard.eatTooMuch();
        //jordansCard.eatFrugal();
        //paulsCard.eatTooMuch();
        //jordansCard.eatTooMuch();
        //paulsCard.eatTooMuch();
        //System.out.println("Pauls card:" + paulsCard);
        //System.out.println("Jordans card:" + jordansCard);



    }
}
