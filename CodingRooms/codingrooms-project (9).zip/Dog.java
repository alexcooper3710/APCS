//AP_CS_Unit 2_P2_ACooper_2022

public class Dog
{
    private int age;
    private String name;
    private int peopleAge;
	
    public Dog( String n )  
    {
    age = 1;
    name = n;
    }
  
    public Dog( String n, int a )  
    {
        name = n;
        age = a;
    }
  
    public void increaseAgeByOne(){
  	    age++;
    }
  
    public int getPeopleAge(int val){
       
        peopleAge = age*val;
    return peopleAge; 
    }
	
    public int getAge()    {
    return age;
    }
	
    public String getName()    {
    return name;
    }
    

    public String toString()    {
    return "Dog - " + name + " " + age;
    }
}
