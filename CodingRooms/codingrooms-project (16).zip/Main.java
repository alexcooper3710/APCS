import java.util.*;
public class Main {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("enter the max number");
        int n = keyboard.nextInt();
        int Sqr = 1;
        while(Math.pow(Sqr,Sqr)<=n){
            System.out.println(Math.pow(Sqr,Sqr));
            Sqr++;
        }
    }

}
