public class U2_RPS{

public static void main(String[] args){

    int personA = (int)(Math.random()*2) + 1;
    System.out.println(personA);

    int personB = (int)(Math.random()*2) + 1;
    System.out.println(personB);

    if(personA == personB){
        System.out.println("It's a tie!");
    }

}
}
