import java.util.*;
public class Main {
    public static void main(String[] args) {
        Apple apple = new Apple("Red Delicious", false, "Caramel");
        System.out.println( apple.getIsCooked() + " " + apple.getTopping() + " apple");
        
        Fruit banana = new Fruit("Banana", false, "Chocolate covered");
        System.out.println(banana.getIsCooked() + " " + banana.getTopping() + " banana");
        
        Food chicken = new Food(true, "chicken", "with rice");
        System.out.println((chicken.getIsCooked()) + " " + chicken.getEat() + " and " + chicken.getSides());
    }
}

class Food {
    private boolean isCooked;
    private String eat;
    private String sides;

    public Food(boolean isCooked, String eat, String sides) {
        this.isCooked = isCooked;
        this.eat = eat;
        this.sides = sides;
    }

    public String getIsCooked() {
        if(this.isCooked == false){
            return "uncooked";
        } else{
            return "cooked";
        }
    }

    public String getEat() {
        return eat;
    }

    public String getSides() {
        return sides;
    }
}

class Fruit extends Food {
    private String name;
    private String topping;

    public Fruit(String name, boolean isCooked, String topping) {
        super(isCooked, "", "");
        this.name = name;
        this.topping = topping;
    }

    public String getName() {
        return name;
    }

    public String getTopping() {
        return topping;
    }
}

class Apple extends Fruit {
    private String name;

    public Apple(String name, boolean isCooked, String topping) {
        super(name, isCooked, topping);
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
