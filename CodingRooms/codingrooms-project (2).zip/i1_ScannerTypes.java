import java.util.*;

public class i1_ScannerTypes {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);

        System.out.println("Enter a message to the user here: ");
        String byebye = keyboard.nextLine();
        System.out.println("You said: " + byebye);
        //
        System.out.println("type an integer");
        int number = keyboard.nextInt();
        System.out.println("you gave the number: " + number);
        //
        System.out.println("type a double");
        double decimal = keyboard.nextDouble();
        System.out.println("you gave the double: " + decimal);
        //
         System.out.println("type a boolean");
        boolean last = keyboard.nextBoolean();
        System.out.println("you gave the boolean: " + last);

        //Hint: See page 4 of the AP CS Unit 1 Lab Prompts. Use "keyboard" instead of "console".
        //Hint2: Look at previous labs to see examples.
        
        
    }
}