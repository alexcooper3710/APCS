import java.util.*;

public class H1_IntegerInput {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Give a number: ");
        int number = keyboard.nextInt();
        System.out.print("you gave the number: " + number);
      
    }
}