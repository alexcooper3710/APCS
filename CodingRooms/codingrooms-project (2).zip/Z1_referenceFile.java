// This file is to remind you how to setup a Java file for a new project

import java.util.*;     //This imports packages. * means every utility package. We use Scanner a lot!

public class Z1_referenceFile {    //Our file is called "reference file". This is where the project begins.
                                //notice referenceFile matches the file name "refenceFile.java" in the left column.
    public static void main(String[] args) {    //This is the main area to run your code. The "instructions"
        Scanner keyboard = new Scanner(System.in);  
        //The line above declares the scanner as an object. We chose "keyboard" as its name.  
        System.out.println("Enter a message here: "); 
        //The line above prints a string in quotes or variables, we can concatenate multiple with "+"
        int number = keyboard.nextInt();
        //The line above reads in the next integer that the user types in the console.

    }
}