import java.util.*;
public class Main {

    public int KthSmallest(int[][] num, int k) {
        int n = num.length;
        int[] temp = new int[n*n];
        int point = 0;
        for(int i = 0; i<num.length; i++){
            for(int j:num[i]){
                temp[point++] = j;
            }
        }
        Arrays.sort(temp);

        return temp[k-1];
    }

}
