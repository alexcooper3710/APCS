class Statistics {
    private double num1;
    private double num2;
    private double num3;
    public static double max(double snum1, double snum2) {
        num1 = snum1;
        num2 = snum2;
        if (num1 > num2) {
            return num1;
        } else {
            return num2;
        }
    }
    public static double min(double snum1, double snum2) {
        num1 = snum1;
        num2 = snum2;
        if (num1 > num2) {
            return num2;
        } else {
            return num1;
        }
    }
    public static double average(double snum1, double snum2, double snum3){
        num1 = snum1;
        num2 = snum2;
        num3 = snum3;
        double av= (num1+num2+num3)/3;

        return av;
    }

}