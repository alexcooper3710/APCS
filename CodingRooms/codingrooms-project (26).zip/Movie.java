class Movie{
    private int rating;
    private String genre;
    private String name;
    public  Movie(String mname, String mgenre, int mrating){
        rating = mrating;
        genre = mgenre;
        name = mname;
    }
    public String toString()
   {
     return name + "\t" + genre + "\t" + rating;
   }
    
}