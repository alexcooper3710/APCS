public class Main {

    public static void main(String[] args) {
     /*   Movie fav = new Movie("Fight Club","Sigma",10);
        Movie worst = new Movie("The Emoji Movie", "Fiction", 0);
        Movie recent = new Movie("Dr Zhivago","Hist Fict", 7);
        
        System.out.println(fav);
        System.out.println(worst);
        System.out.println(recent);
*/
        double maximum = Statistics.max(0.32, 7.52);
        double minimum = Statistics.min(34.93, 5.9);
        double av = Statistics.average(32.4,75.9,2.7);
        System.out.println(maximum);
        System.out.println(minimum);
        System.out.println(av);
       
    }

}
