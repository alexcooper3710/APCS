import java.util.*;
public class primeFactor{

public static void main(String[] args){

    Scanner keyboard = new Scanner(System.in);
    System.out.print("Enter a number: ");
    int num = keyboard.nextInt();
    int counter = 2;
    while(counter <=num){
        if(num%counter == 0){
        System.out.println(counter);
        num= num/counter;
        }
            else{
               counter++;
            }
    }

 }
}