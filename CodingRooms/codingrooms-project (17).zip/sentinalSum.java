import java.util.*;
public class sentinalSum {

    public static void main(String[] args) {
      Scanner keyboard = new Scanner(System.in);
      int total = 0;
      System.out.println("Type a number");
      int num = keyboard.nextInt();

        while(num != -1){
            total = num + total;

            System.out.println("Type a number");
             num = keyboard.nextInt();
        }
    System.out.println(total);
    }

}
