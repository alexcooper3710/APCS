import java.util.*;

public class guessingGame{

    public static void main(String[]args){
        Scanner keyboard = new Scanner(System.in);

        int test = (int)(Math.random()*21);
         
        System.out.print("Guess a number ");
        int guess = keyboard.nextInt();

        if(guess==test){
            System.out.println("You got it, congratulations!");
        } else {
            System.out.println("you guessed wrong.");
        }
    }
}