import java.util.*;
public class GuessingGameRunner{
    public static void main(String[] args){
        int game = 1;
        GuessingGame= new GuessingGame(game);
        game++;


    }
}