import java.util.*;
public class GuessingGame {
    private int game;

        public GuessingGame( int G){
            G= game;
        Scanner keyboard = new Scanner(System.in);
        int number = (int)(Math.random()*100)+1;
        System.out.print("Guess a number 1-100: ");
        int guess = keyboard.nextInt();
        int tries = 1;

            while(guess!= number){
                if (guess< number){
                    System.out.println("It's higher.");
                } else if (guess> number){
                    System.out.println("It's lower.");
                }
                System.out.print("Guess a new number: ");
                guess = keyboard.nextInt();
                tries++;
            }
       if(tries == 1){
           System.out.print("You got it in 1 Guess!");
       } else 
       System.out.print("You got it in " + tries + " guesses");
    }
}


