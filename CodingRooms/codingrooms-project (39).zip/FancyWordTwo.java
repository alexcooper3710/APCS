//AP Computer Science Name -

import java.util.Scanner;
import static java.lang.System. *;
import java.util.Arrays;

public class FancyWordTwo {

    private String[][] mat;

    public FancyWordTwo() {
        mat = new String[0][0];
    }

    public FancyWordTwo(String s) {
              int end = s.length();
        mat = new String[2 * end - 1][2 * end - 1];

        for (String[] row : mat) {
            Arrays.fill(row, " ");
        }

        for (int i = 0; i < end; i++) {
            mat[0][i] = s.substring(i, i + 1);
            mat[i][0] = s.substring(i, i + 1);
            mat[end - 1][i] = s.substring(end - i - 1, end - i);
            mat[i][end - 1] = s.substring(end - i - 1, end - i);

            mat[i][i] = s.substring(i, i + 1);
            mat[end + i - 2][i] = s.substring(end - i - 1, end - i);
            mat[i][end + i - 2] = s.substring(end - i - 1, end - i);
            mat[end + i - 2][end + i - 2] = s.substring(i, i + 1);
        }
    }

    public String toString() {
        StringBuilder output = new StringBuilder();
        for (String[] row : mat) {
            for (String c : row) {
                output.append(c);
            }
            output.append("\n");
        }
        return output.toString();
    }
}
