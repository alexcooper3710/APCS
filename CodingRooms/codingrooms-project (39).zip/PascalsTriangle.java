//AP Computer Science
//Name -

import java.util.Scanner;
import static java.lang.System.*;

public class PascalsTriangle
{
	private int[][] mat;

	public PascalsTriangle()
	{


	}

	public PascalsTriangle(int size)
	{


	}

	public void createTriangle()
	{





	}

	public String toString()
	{
		String output="";







		return output;
	}
}