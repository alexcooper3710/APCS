//AP Computer Science
//Name -

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import static java.lang.System.*;

public class FancyWordTwoRunner
{
	public static void main( String args[] ) throws IOException
	{  
        Scanner file = new Scanner(new File("fancyword2.dat"));
        int size = file.nextInt();
        file.nextLine();
        for (int i = 0; i < size; i++) {
            String word = file.nextLine();
            FancyWord one = new FancyWord(word);
            System.out.println(one);
        }
    
	}
}