import java.util.Scanner;
public class MyMath
{
/**
* Returns the sum of all integers from 1 to n, if n >= 1,
* and 0 otherwise.
*/
public static int sumUpTo(int n)
{
int sum = 0;
int prevsum = 0;
for( int i = 0; i<n; i++){

  sum+=i+1;
   
}
return sum;
}

//Returns 1 * 2 * ... * n, if n >= 1; otherwise returns 1
public static long factorial(int n)
{
    int fact = 1;
    for( int i = 1; i<=n; i++){

    fact=(fact*i);
   
}
return fact;
}

//Returns true if n is a prime; otherwise returns false
public static boolean isPrime(int n)
{
    boolean iP = true; //isPrime

   
        if(n%2 ==0){
            iP = false;
        }
    
    return iP;
}


//Creates an n x n multiplcation table
public static void makeMultiplicationTable(int n)
{

for (int a=1; a<=n; ++a)
{
    for (int b=1; b<=n; b++)
    {
        System.out.print( a*b+ "\t");  
    }
    System.out.println();
}    }
/*
//Tests Goldbach conjecture for even numbers up to bigNum
public static boolean testGoldbach(int bigNum)
{
// your code here. Hint - use a nested for loop
}
//Returns true if n is a perfect number, false otherwise
public static boolean isPerfect(int n)
{
// your code here
}
*/
//********************************************************************
public static void main(String[] args)
{
Scanner kb = new Scanner(System.in);
int n;
do
{
System.out.print("Enter an integer from 4 to 20: ");
n = kb.nextInt();
} while (n < 4 || n > 20);
kb.close();
System.out.println();
System.out.println("1 + ... + " + n + " = " + sumUpTo(n));

System.out.println(n + "! = " + factorial(n));

System.out.print("Prime: ");

System.out.print(isPrime(n));
System.out.println();

System.out.println(n + " by " + n + " multiplication table: ");
makeMultiplicationTable(n);
System.out.println();
/*
System.out.println("Goldbach conjecture up to " + n + ": " +
testGoldbach(n));
System.out.println(n + " is a perfect number: " + isPerfect(n));
*/
}
}